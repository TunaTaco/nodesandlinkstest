import React, {Fragment} from 'react';
import './App.css';
import MatchListComponent from "./components/MatchListComponent";

function App() {

  return <Fragment>
    <MatchListComponent/>
  </Fragment>
}

export default App;
